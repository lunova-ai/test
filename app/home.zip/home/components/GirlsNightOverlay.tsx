import type { CSSProperties } from "react";

export function GirlsNightOverlay({
  open,
  animateBubbles,
  onClose,
}: {
  open: boolean;
  animateBubbles: boolean;
  onClose: () => void;
}) {
  if (!open) return null;

  return (
    <div
      className="girls-overlay"
      role="dialog"
      aria-modal="true"
      aria-label="Mädlsabend Details"
      onClick={onClose}
    >
      <button
        type="button"
        className="girls-close"
        aria-label="Schließen"
        onClick={onClose}
      >
        ✕
      </button>

      <div className="girls-popup" onClick={(e) => e.stopPropagation()}>
        <p className="text-xs tracking-[0.28em] uppercase girls-eyebrow">
          Mädlsabend
        </p>

        <h2 className="mt-2 text-2xl md:text-3xl font-cinzel tracking-tight girls-title">
          🍸 Jeden Donnerstag ab 16 Uhr
        </h2>

        <p className="mt-3 text-base md:text-lg girls-text leading-relaxed">
          Gratis Cocktail{" "}
          <span className="girls-muted">(mit &amp; ohne Alk.)</span> – bei uns an der Bar.
        </p>

        <div className="mt-5 girls-box">
          <p className="text-sm">
            📞 Tischreservierung:{" "}
            <a className="girls-link" href="tel:+436649238843">
              +43 664 923 8843
            </a>
          </p>
          <p className="mt-1 text-sm girls-muted">
            Komm vorbei – oder reserviere kurz telefonisch / per WhatsApp.
          </p>
        </div>

        <div className="mt-6 flex flex-wrap gap-3 justify-center">
          <a href="tel:+436649238843" className="btn-brand text-sm md:text-base">
            Jetzt anrufen
          </a>
          <a href="/kontakt" className="btn-outline text-sm md:text-base">
            Anfrage senden
          </a>
        </div>

        <p className="mt-4 text-xs girls-muted">
          Tipp: ESC oder Klick außerhalb schließt das Fenster.
        </p>
      </div>

      {animateBubbles && (
        <div className="bubble-layer" aria-hidden="true">
          {Array.from({ length: 22 }).map((_, i) => {
            const size = 10 + Math.random() * 26; // 10..36
            const dur = 5 + Math.random() * 7; // 5..12
            const delay = Math.random() * 0.8;
            const drift = (Math.random() * 2 - 1) * 60;

            const style = {
              left: `${Math.random() * 96}%`,
              width: `${size}px`,
              height: `${size}px`,
              animationDuration: `${dur}s`,
              animationDelay: `${delay}s`,
              ["--drift" as any]: `${drift}px`,
              opacity: 0.10 + Math.random() * 0.22,
            } as CSSProperties;

            return <div key={i} className="bubble" style={style} />;
          })}
        </div>
      )}
    </div>
  );
}
