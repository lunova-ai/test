import FadeIn from "./FadeIn";

export function SpecialsSection({
  onOpenBirthday,
  onOpenGirlsNight,
}: {
  onOpenBirthday: () => void;
  onOpenGirlsNight: () => void;
}) {
  return (
    <section
      id="specials"
      className="relative w-full border-b border-[#e1ddd8] bg-[var(--cream)] scroll-mt-24"
    >
      <div className="pointer-events-none absolute -top-24 -left-24 h-72 w-72 rounded-full bg-[var(--brand)]/10 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-[var(--brand)]/10 blur-3xl" />

      <div className="relative max-w-6xl mx-auto px-6 py-16 md:py-20">
        <FadeIn>
          <p className="text-xs tracking-[0.28em] uppercase text-[var(--brand)]">
            Specials
          </p>
        </FadeIn>

        <FadeIn>
          <div className="mt-2 flex flex-col md:flex-row md:items-end md:justify-between gap-6">
            <div>
              <h2 className="text-3xl md:text-4xl font-cinzel tracking-tight text-[var(--dark)]">
                Veranstaltungen &amp; Aktionen
              </h2>
              <p className="mt-3 text-base md:text-lg text-[#555] max-w-2xl">
                Kindergeburtstage &amp; Mädlsabend – zwei fixe Highlights bei uns im Casa.
              </p>
            </div>
          </div>
        </FadeIn>

        {/* 2 Premium Cards */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Kindergeburtstag */}
          <FadeIn>
            <button
              type="button"
              onClick={onOpenBirthday}
              className="card special-card special-card-kids text-left w-full hover:-translate-y-[2px] transition-transform"
              aria-label="Kindergeburtstag Details öffnen"
            >
              <div className="special-card-bg" aria-hidden="true" />

              <p className="text-xs tracking-[0.22em] uppercase text-[var(--brand)] mb-2 relative z-[1]">
                Kindergeburtstag
              </p>

              <div className="relative z-[1]">
                <h3 className="text-2xl md:text-3xl font-cinzel mb-2 text-[var(--dark)]">
                  🎈 Pizza Spezialpreis
                </h3>
                <p className="text-[#555] text-sm md:text-base leading-relaxed">
                  Ab <span className="font-semibold">5 Kindern</span> – unkompliziert feiern,
                  essen &amp; Spaß haben.
                </p>

                {/* “Flyer”-Grafik (neu gestaltet, kein Original) */}
                <div className="special-poster special-poster-kids mt-5">
                  <p className="special-poster-top">
                    Kindergeburtstag im <span className="font-cinzel">La mia Casa</span>
                  </p>
                  <p className="special-poster-mid">
                    🎉 Ab 5 Kindern
                    <br />
                    <span className="special-poster-em">Pizza Spezialpreis</span>
                  </p>
                  <p className="special-poster-sub">
                    Reservierung:{" "}
                    <span className="special-poster-phone">0664 9238843</span>
                  </p>
                </div>

                <div className="mt-6 flex items-center gap-3">
                  <span className="special-chip">Ballons &amp; Party-Vibes</span>
                  <span className="special-link">
                    Details öffnen →
                  </span>
                </div>
              </div>
            </button>
          </FadeIn>

          {/* Mädlsabend */}
          <FadeIn>
            <button
              type="button"
              onClick={onOpenGirlsNight}
              className="card special-card special-card-girls text-left w-full hover:-translate-y-[2px] transition-transform"
              aria-label="Mädlsabend Details öffnen"
            >
              <div className="special-card-bg girls" aria-hidden="true" />

              <p className="text-xs tracking-[0.22em] uppercase text-[var(--brand)] mb-2 relative z-[1]">
                Mädlsabend
              </p>

              <div className="relative z-[1]">
                <h3 className="text-2xl md:text-3xl font-cinzel mb-2 text-[var(--dark)]">
                  🍸 Jeden Donnerstag
                </h3>
                <p className="text-[#555] text-sm md:text-base leading-relaxed">
                  Ab <span className="font-semibold">16 Uhr</span> – gratis Cocktail{" "}
                  <span className="text-[#666]">(mit &amp; ohne Alk.)</span> bei uns an der Bar.
                </p>

                <div className="special-poster special-poster-girls mt-5">
                  <p className="special-poster-top girls">
                    Auch diesen <span className="font-cinzel">Donnerstag</span>
                  </p>
                  <p className="special-poster-mid girls">
                    Manchmal ist ein
                    <br />
                    <span className="special-poster-em girls">Mädlsabend</span>
                    <br />
                    die beste Therapie ✨
                  </p>
                  <p className="special-poster-sub girls">
                    ab <span className="special-poster-time">16 Uhr</span> · gratis Cocktail
                  </p>
                </div>

                <div className="mt-6 flex items-center gap-3">
                  <span className="special-chip girls">Glow &amp; Bubbles</span>
                  <span className="special-link">
                    Details öffnen →
                  </span>
                </div>
              </div>
            </button>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
